
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactTest {
    protected String contactId, firstNameTest, lastNameTest, phoneNumberTest,
            addressTest;
    protected String tooLongContactId, tooLongFirstName, tooLongLastName,
            tooLongPhoneNumber, tooShortPhoneNumber, tooLongAddress;

    @BeforeEach
    void setUp() { //setting up testing params
        contactId = "1234567";
        firstNameTest = "Student";
        lastNameTest = "Random";
        phoneNumberTest = "1234567890";
        addressTest = "1234 seseme street";
        tooLongContactId = "112233445566778899";
        tooLongFirstName = "Leeeeeeeeeerooooooooooyyyy";
        tooLongLastName = "mmmmmJennnnnkinsssss";
        tooLongPhoneNumber = "7993445903744";
        tooShortPhoneNumber = "2233";
        tooLongAddress = "23 Zapp Branigan Street Apt 2458 hwy 47";
    }


    @Test
    void contactTest() { //testing new contact
        Contact contact = new Contact();
        assertAll("constructor",
                ()
                        -> assertNotNull(contact.getContactId()),
                ()
                        -> assertNotNull(contact.getFirstName()),
                ()
                        -> assertNotNull(contact.getLastName()),
                ()
                        -> assertNotNull(contact.getPhoneNumber()),
                () -> assertNotNull(contact.getAddress()));
    }

    @Test
    void contactIdConstructorTest() { //testing contact ID to ensure they aren't empty
        Contact contact = new Contact(contactId);
        assertAll("constructor one",
                ()
                        -> assertEquals(contactId, contact.getContactId()),
                ()
                        -> assertNotNull(contact.getFirstName()),
                ()
                        -> assertNotNull(contact.getLastName()),
                ()
                        -> assertNotNull(contact.getPhoneNumber()),
                () -> assertNotNull(contact.getAddress()));
    }


    @Test
    void contactConstructorTest() { //testing that each item can use the contact.get function properly
        Contact contact = new Contact(contactId, firstNameTest, lastNameTest,
                phoneNumberTest, addressTest);
        assertAll("constructor all",
                ()
                        -> assertEquals(contactId, contact.getContactId()),
                ()
                        -> assertEquals(firstNameTest, contact.getFirstName()),
                ()
                        -> assertEquals(lastNameTest, contact.getLastName()),
                ()
                        -> assertEquals(phoneNumberTest, contact.getPhoneNumber()),
                () -> assertEquals(addressTest, contact.getAddress()));
    }

    @Test
    void updateFirstNameTest() {  //testing that update is working
        Contact contact = new Contact();
        contact.updateFirstName(firstNameTest);
        assertAll(
                "first name",
                ()
                        -> assertEquals(firstNameTest, contact.getFirstName()),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        () -> contact.updateFirstName(null)), //testing that illegal arguments are showing
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        () -> contact.updateFirstName(tooLongFirstName)));
    }

    @Test
    void updateLastNameTest() {
        Contact contact = new Contact();
        contact.updateLastName(lastNameTest);
        assertAll(
                "last name",
                ()
                        -> assertEquals(lastNameTest, contact.getLastName()),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        () -> contact.updateLastName(null)),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        () -> contact.updateLastName(tooLongFirstName)));
    }

    @Test
    void updatePhoneNumberTest() {
        Contact contact = new Contact();
        contact.updatePhoneNumber(phoneNumberTest);
        assertAll("phone number",
                ()
                        -> assertEquals(phoneNumberTest, contact.getPhoneNumber()),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        () -> contact.updatePhoneNumber(null)),
                ()
                        -> assertThrows(
                        IllegalArgumentException.class,
                        () -> contact.updatePhoneNumber(tooLongPhoneNumber)),
                ()
                        -> assertThrows(
                        IllegalArgumentException.class,
                        () -> contact.updatePhoneNumber(tooShortPhoneNumber)),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        () -> contact.updatePhoneNumber(contactId)));
    }

    @Test
    void updateAddressTest() {
        Contact contact = new Contact();
        contact.updateAddress(addressTest);
        assertAll("phone number",
                ()
                        -> assertEquals(addressTest, contact.getAddress()),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        () -> contact.updateAddress(null)),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        () -> contact.updateAddress(tooLongAddress)));
    }

    @Test
    void updateContactIdTest() {
        Contact contact = new Contact();
        contact.updateContactId(contactId);
        assertAll(
                "contact ID",
                ()
                        -> assertEquals(contactId, contact.getContactId()),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        () -> contact.updateContactId(null)),
                ()
                        -> assertThrows(IllegalArgumentException.class,
                        () -> contact.updateContactId(tooLongContactId)));
    }
}