import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TaskTest {

    private String id, name, description;
    private String tooLongId, tooLongName, tooLongDescription;

    @BeforeEach
    void setUp() {
        id = "1234567890";
        name = "Walk the dog ";
        description = "Its something that you do every morning";
        tooLongId = "111222333444555666777888999";
        tooLongName = "super long task description name";
        tooLongDescription =
                "super long description for this task that can be used to test if it is working or as the requriments state it needs more than 50 charicaters.";
    }

    @Test
    void getTaskIdTest() { //checking task ID
        Task task = new Task(id);
        Assertions.assertEquals(id, task.getTaskId());
    }

    @Test
    void getNameTest() { //checking name
        Task task = new Task(id, name);
        Assertions.assertEquals(name, task.getName());
    }

    @Test
    void getDescriptionTest() { //checking description
        Task task = new Task(id, name, description);
        Assertions.assertEquals(description, task.getDescription());
    }

    @Test
    void setNameTest() { //setting name and checking its set
        Task task = new Task();
        task.setName(name);
        Assertions.assertEquals(name, task.getName());
    }

    @Test
    void setDescriptionTest() { //setting description and checking its set
        Task task = new Task();
        task.setDescription(description);
        Assertions.assertEquals(description, task.getDescription());
    }

    @Test
    void TaskIdTooLongTest() { //checking illegal argument is thrown if ID is too long
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Task(tooLongId));
    }

    @Test
    void setTooLongNameTest() { //checking illegal argument is throwing is name is too long
        Task task = new Task();
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> task.setName(tooLongName));
    }

    @Test
    void setTooLongDescriptionTest() { //checking illegal argument is throwing is description is too long
        Task task = new Task();
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> task.setDescription(tooLongDescription));
    }

    @Test
    void TaskIdNullTest() { //checking illegal argument is thrown if new task is null
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> new Task(null));
    }

    @Test
    void TaskNameNullTest() { //checking illegal argument is thrown if name is set to null
        Task task = new Task();
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> task.setName(null));
    }

    @Test
    void TaskDescriptionNullTest() { //checking an illegal argument is thrown if description is set to null
        Task task = new Task();
        Assertions.assertThrows(IllegalArgumentException.class,
                () -> task.setDescription(null));
    }
}