import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
    //setting up variables
    private String id;
    private String description;
    private String tooLongDescription;
    private Date date;
    private Date pastDate;

    @SuppressWarnings("deprecation") // date deprecated and the noticed for that is being suppressed
    @BeforeEach
    void setUp() { //passing items to varaibles
        id = "1234567890";
        description = "This is the description test description";
        date = new Date(2021, Calendar.JANUARY, 1);
        tooLongDescription =
                "this is the long description to test if the description is throwing an illegal argument as it should be";
        pastDate = new Date(0);
    }

    @Test //testing the new appointment function
    void testNewAppointment() {
        AppointmentService service = new AppointmentService();

        service.newAppointment(); //checking that its not null
        assertNotNull(service.getAppointmentList().get(0).getAppointmentId());
        assertNotNull(service.getAppointmentList().get(0).getAppointmentDate());
        assertNotNull(service.getAppointmentList().get(0).getDescription());

        service.newAppointment(date);  //new appointment using date
        assertNotNull(service.getAppointmentList().get(1).getAppointmentId());
        assertEquals(date,
                service.getAppointmentList().get(1).getAppointmentDate());
        assertNotNull(service.getAppointmentList().get(1).getDescription());

        service.newAppointment(date, description); //new appointment using date and description
        assertNotNull(service.getAppointmentList().get(2).getAppointmentId());
        assertEquals(date,
                service.getAppointmentList().get(2).getAppointmentDate());
        assertEquals(description,
                service.getAppointmentList().get(2).getDescription());

        assertNotEquals(service.getAppointmentList().get(0).getAppointmentId(), //checking that the IDs
                service.getAppointmentList().get(1).getAppointmentId());       // of the appointments
        assertNotEquals(service.getAppointmentList().get(0).getAppointmentId(), //dont match
                service.getAppointmentList().get(2).getAppointmentId());
        assertNotEquals(service.getAppointmentList().get(1).getAppointmentId(),
                service.getAppointmentList().get(2).getAppointmentId());

        assertThrows(IllegalArgumentException.class,  //checking that when used the past date  and long description
                () -> service.newAppointment(pastDate));  // result in an illegal argument being thrown
        assertThrows(IllegalArgumentException.class,
                () -> service.newAppointment(date, tooLongDescription));
    }

    @Test
    void deleteAppointment() throws Exception {
        AppointmentService service = new AppointmentService();

        service.newAppointment(); //generating new appointments
        service.newAppointment();
        service.newAppointment();

        String firstId = service.getAppointmentList().get(0).getAppointmentId(); //assigning ID to a string
        String secondId = service.getAppointmentList().get(1).getAppointmentId();
        String thirdId = service.getAppointmentList().get(2).getAppointmentId();

        assertNotEquals(firstId, secondId); // checking they arent the same
        assertNotEquals(firstId, thirdId);
        assertNotEquals(secondId, thirdId);
        assertNotEquals(id, firstId);
        assertNotEquals(id, secondId);
        assertNotEquals(id, thirdId);

        assertThrows(Exception.class, () -> service.deleteAppointment(id)); //deleting

        service.deleteAppointment(firstId); //deleting
        assertThrows(Exception.class, () -> service.deleteAppointment(firstId));
        assertNotEquals(firstId,
                service.getAppointmentList().get(0).getAppointmentId()); //checking the string and appointment aren't equal

    }
}