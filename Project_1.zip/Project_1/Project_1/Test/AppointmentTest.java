import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AppointmentTest {

    private String id, description;
    private String tooLongId, tooLongDescription;
    private Date date, pastDate;

    @SuppressWarnings("deprecation") //suppressing deprecation warning because of java.until.Date
    @BeforeEach
    void setUp() {
        id = "1234567890";
        description = "This is the description test description";
        date = new Date(2021, Calendar.JANUARY, 1);
        tooLongId = "1293857194750838018849792984";
        tooLongDescription =
                "this is the long description to test if the description is throwing an illegal argument as it should be";
        pastDate = new Date(0);
    }

    @Test
    void testUpdateAppointmentId() { //dating the appointment up update feature
        Appointment appointment = new Appointment();
        assertThrows(IllegalArgumentException.class, //throwing an illegal argument if null
                () -> appointment.updateAppointmentId(null));
        assertThrows(IllegalArgumentException.class,
                () -> appointment.updateAppointmentId(tooLongId)); //thrwoing an illegal argument if too long
        appointment.updateAppointmentId(id);

    }

    @Test
    void testGetAppointmentId() { //testing getting the appointment ID
        Appointment appointment = new Appointment(id);
        assertNotNull(appointment.getAppointmentId()); //checking if its null
        assertEquals(appointment.getAppointmentId().length(), 10); //checking its length
        assertEquals(id, appointment.getAppointmentId()); //testing that its being assigned correctly
    }

    @Test
    void testUpdateDate() {
        Appointment appointment = new Appointment(); //testing that illegal arguments are being thrown correctly
        assertThrows(IllegalArgumentException.class, () -> appointment.updateDate(null)); //for the date
        assertThrows(IllegalArgumentException.class,
                () -> appointment.updateDate(pastDate));
        appointment.updateDate(date);
    }

    @Test
    void testGetAppointmentDate() {
        Appointment appointment = new Appointment(id, date);
        assertNotNull(appointment.getAppointmentDate()); //testing its not null
        assertEquals(date, appointment.getAppointmentDate()); //testing date is being assigned correctly
    }

    @Test
    void testUpdateDescription() { //testing illegal arguments are being thrown correclty
        Appointment appointment = new Appointment(); //for the description
        assertThrows(IllegalArgumentException.class,
                () -> appointment.updateDescription(null));
        assertThrows(IllegalArgumentException.class,
                () -> appointment.updateDescription(tooLongDescription));
        appointment.updateDescription(description);
    }

    @Test
    void testGetDescription() {
        Appointment appointment = new Appointment(id, date, description);
        assertNotNull(appointment.getDescription()); //testing that its not null
        assertTrue(appointment.getDescription().length() <= 50); //testing that its the correctly length
        assertEquals(description, appointment.getDescription()); //testing that its being assigned correctly
    }
}