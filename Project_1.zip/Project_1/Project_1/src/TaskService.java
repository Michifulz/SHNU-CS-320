import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TaskService {

    private final List<Task> taskObject = new ArrayList<>(); //creating task object as array list

    private String newUniqueId() { //setting new ID as random
        return UUID.randomUUID().toString().substring(
                0, Math.min(toString().length(), 10));
    }

    private Task searchForTask(String id) throws Exception { //creating a search
        int index = 0;
        while (index < taskObject.size()) {
            if (id.equals(taskObject.get(index).getTaskId())) {
                return taskObject.get(index);
            }
            index++;
        }
        throw new Exception("The Task does not exist!");
    }

    public void newTask() { //new task
        Task task = new Task(newUniqueId());
        taskObject.add(task);
    }

    public void newTask(String name) { //new task with name
        Task task = new Task(newUniqueId(), name);
        taskObject.add(task);
    }

    public void newTask(String name, String description) { //new task with all
        Task task = new Task(newUniqueId(), name, description);
        taskObject.add(task);
    }

    public void deleteTask(String id) throws Exception { //delete task
        taskObject.remove(searchForTask(id));
    }

    public void updateTaskName(String id, String name) throws Exception { //update taskname
        searchForTask(id).setName(name);
    }

    public void updateTaskDescription(String id, String description)
            throws Exception {
        searchForTask(id).setDescription(description);
    }

    public List<Task> getTaskList() { return taskObject; }
}