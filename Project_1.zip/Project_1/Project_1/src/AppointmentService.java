
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class AppointmentService {
    final private List<Appointment> appointmentObject = new ArrayList<>();

    private String newUniqueId() { //generating random ID
        return UUID.randomUUID().toString().substring(
                0, Math.min(toString().length(), 10));
    }

    public void newAppointment() {
        Appointment appointment = new Appointment(newUniqueId()); //new appointment objects have unique IDs
        appointmentObject.add(appointment); //adding new appointment object
    }

    public void newAppointment(Date date) {
        Appointment appointment = new Appointment(newUniqueId(), date); //new appointment object with unique ID and date
        appointmentObject.add(appointment);
    }

    public void newAppointment(Date date, String description) {
        Appointment appointment = new Appointment(newUniqueId(), date, description); //new appointment obbject with
        appointmentObject.add(appointment); //unique ID, date, and description
    }

    public void deleteAppointment(String id) throws Exception {
        appointmentObject.remove(searchForAppointment(id)); //removing using the search with using the ID
    }

    protected List<Appointment> getAppointmentList() { return appointmentObject; }

    private Appointment searchForAppointment(String id) throws Exception { //seach function
        int i = 0;
        while (i < appointmentObject.size()) { //looping using the size of the object
            if (id.equals(appointmentObject.get(i).getAppointmentId())) { //getting the ID
                return appointmentObject.get(i); //returning the appointment object
            }
            i++;
        }
        throw new Exception("The appointment does not exist!");
    }
}