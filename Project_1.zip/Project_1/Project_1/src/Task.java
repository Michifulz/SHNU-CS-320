public class Task {

    private String taskId;
    private String name;
    private String description;

    Task() { //initializing task
        taskId = "INITIAL";
        name = "INITIAL";
        description = "INITIAL DESCRIPTION";
    }

    Task(String taskId) { //creating task methods that take name, ID, and description inputs
        checkTaskId(taskId);
        name = "INITIAL";
        description = "INITIAL DESCRIPTION";
    }

    Task(String taskId, String name) {
        checkTaskId(taskId);
        setName(name);
        description = "INITIAL DESCRIPTION";
    }

    Task(String taskId, String name, String description) {
        checkTaskId(taskId);
        setName(name);
        setDescription(description);
    }

    public final String getTaskId() { return taskId; } //returning

    public final String getName() { return name; }

    public final String getDescription() { return description; }

    protected void setName(String name) {
        if (name == null || name.length() > 20) { //checking for name length
            throw new IllegalArgumentException(
                    "Task name is invalid. Ensure it is shorter than 20 characters and not empty.");
        } else {
            this.name = name;
        }
    }

    protected void setDescription(String taskDescription) {
        if (taskDescription == null || taskDescription.length() > 50) { //checking for description length
            throw new IllegalArgumentException(
                    "Task description is invalid. Ensure it is shorter than 50 characters and not empty.");
        } else {
            this.description = taskDescription;
        }
    }

    private void checkTaskId(String taskId) {
        if (taskId == null || taskId.length() > 10) { //checking for ID length
            throw new IllegalArgumentException(
                    "Error: The task ID was null or longer than 10 characters");
        } else {
            this.taskId = taskId;
        }
    }
}
